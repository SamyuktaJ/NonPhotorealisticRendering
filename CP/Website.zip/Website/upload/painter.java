import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;


public class painter {


	public static void main(String args[]) {
		
		//JFileChooser prompt = new JFileChooser("G:\\School\\CompPhoto\\Project");
		File inputimage = new File("");
		int ret = 0;
		if(args.length < 1) {
			System.out.println("Error, no file given");
			System.exit(0);
		}
		else {
			//prompt.setSelectedFile(new File(args[0]));
			inputimage = new File(args[0]);
		}
		
		BufferedImage input = null;
		try {
			//input = ImageIO.read(prompt.getSelectedFile());
			input = ImageIO.read(inputimage);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		int height = input.getHeight();
		int width = input.getWidth();
		int scale = 7;
		int hr = height / scale;
		int wr = width / scale;
		Random rand = new Random(hr * wr);
		int h = 0;
		int w = 0;
		int r = 0;
		int rgb = 0;
		int t = 0;
		int stroke_len = 7;
		int stroke_wid = 7;
		BufferedImage output = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		Graphics2D goutput = output.createGraphics();
		goutput.setStroke(new BasicStroke((stroke_wid * 1.0f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
		goutput.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		goutput.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
		
		
		
		int[] strokes = new int[hr * wr];
		for(int i = 0; i < (hr * wr); i++) {
			strokes[i] = i;
		}
		
		for(int i = ((hr * wr) - 1); i >= 0; i--) {
			r = rand.nextInt(hr * wr);
			t = strokes[i];
			strokes[i] = strokes[r];
			strokes[r] = t;
		}
		
		
		try {
			for (int i = 0; i < (hr * wr); i++) {
				r = strokes[i];
				h = (r / wr) * scale;
				w = (r % wr) * scale;
				
				if( (h < stroke_len) || (w > (width - stroke_len)))
					continue;
				
				rgb = input.getRGB(w, h);
				rgb = perturbRGB(rgb);
				goutput.setColor(new Color(rgb));
				
				goutput.draw(new Line2D.Double((double)w, (double)h, 
						(double)(w+((stroke_len*(1+Math.random()))*1.0f)*Math.cos((Math.random()-.5)/3*Math.PI+Math.PI/4)), 
						(double)(h-((stroke_len*(1+Math.random()))*1.0f)*Math.sin((Math.random()-.5)/3*Math.PI+Math.PI/4))));

			}
		}
		catch (Exception e) {
			//e.printStackTrace();
		}
		
		
		//String abspth = prompt.getSelectedFile().getAbsolutePath();
		String abspth = inputimage.getAbsolutePath();
		//File outputfile = new File(abspth.substring(0,abspth.lastIndexOf(File.separator)) + "\\painterly_" + prompt.getSelectedFile().getName());
		File outputfile = new File(abspth.substring(0,abspth.lastIndexOf(File.separator)) + "/painterly_" + inputimage.getName());
		try {
			ImageIO.write(output, "png", outputfile);
		} catch (IOException e) {
			//e.printStackTrace();
		}
		
	}
	
	private static int perturbRGB(int rgb) {
		int newrgb = 0;
		int perturb = 25;
		int r = ((rgb >> 16) & 0xFF) + (int)(Math.random() * perturb) - perturb/2;
		int g = ((rgb >> 8) & 0xFF) + (int)(Math.random() * perturb) - perturb/2;
		int b = (rgb & 0xFF) + (int)(Math.random() * perturb) - perturb/2;
		
		r = (r > 0) ? ((r < 255) ? r : 255) : 0;
		g = (g > 0) ? ((g < 255) ? g : 255) : 0;
		b = (b > 0) ? ((b < 255) ? b : 255) : 0;

		newrgb = r;
		newrgb = (newrgb << 8) + g;
		newrgb = (newrgb << 8) + b;
		return newrgb;
	}

}
