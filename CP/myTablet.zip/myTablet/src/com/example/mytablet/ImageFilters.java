package com.example.mytablet;

import android.graphics.Bitmap;
//import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
//import android.graphics.LinearGradient;
//import android.graphics.Matrix;
import android.graphics.Paint;
//import android.graphics.PorterDuff;
//import android.graphics.PorterDuffXfermode;
//import android.graphics.Rect;
//import android.graphics.RectF;
//import android.graphics.Shader;

import java.util.Random;

public class ImageFilters {
	
	public  Bitmap applyDecreaseColorDepthEffect(Bitmap src, int bitOffset) {
        // get image size
        int width = src.getWidth();
        int height = src.getHeight();
        // create output bitmap
        Bitmap bmOut = Bitmap.createBitmap(width, height, src.getConfig());
        // color information
        int A, R, G, B;
        int pixel;

        // scan through all pixels
        for(int x = 0; x < width; ++x) {
            for(int y = 0; y < height; ++y) {
                // get pixel color
                pixel = src.getPixel(x, y);
                A = Color.alpha(pixel);
                R = Color.red(pixel);
                G = Color.green(pixel);
                B = Color.blue(pixel);

                // round-off color offset
                R = ((R + (bitOffset / 2)) - ((R + (bitOffset / 2)) % bitOffset) - 1);
                if(R < 0) { R = 0; }
                G = ((G + (bitOffset / 2)) - ((G + (bitOffset / 2)) % bitOffset) - 1);
                if(G < 0) { G = 0; }
                B = ((B + (bitOffset / 2)) - ((B + (bitOffset / 2)) % bitOffset) - 1);
                if(B < 0) { B = 0; }

                // set pixel color to output bitmap
                bmOut.setPixel(x, y, Color.argb(A, R, G, B));
            }
        }

        // return final image
        return bmOut;
    }
	public Bitmap applyGaussianBlurEffect(Bitmap src) {
        double[][] GaussianBlurConfig = new double[][] {
                { 1, 2, 1 },
                { 2, 4, 2 },
                { 1, 2, 1 }
        };
        ConvolutionMatrix convMatrix = new ConvolutionMatrix(3);
        convMatrix.applyConfig(GaussianBlurConfig);
        convMatrix.Factor = 16;
        convMatrix.Offset = 0;
        return ConvolutionMatrix.computeConvolution3x3(src, convMatrix);
    }
	
	public Bitmap applyPainterly(Bitmap input) {
		
			int height = input.getHeight();
			int width = input.getWidth();
			int scale = 7;
			int hr = height / scale;
			int wr = width / scale;
			Random rand = new Random(hr * wr);
			int h = 0;
			int w = 0;
			int r = 0;
			int rgb = 0;
			int t = 0;
			int stroke_len = 7;
			int stroke_wid = 7;
			//BufferedImage output = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Bitmap output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
			//Graphics2D goutput = output.createGraphics();
			Canvas goutput = new Canvas(output);
			Paint p = new Paint();
			p.setAntiAlias(true);
			p.setStrokeWidth((stroke_wid * 1.0f));
			p.setStrokeCap(Paint.Cap.ROUND);
			p.setStrokeJoin(Paint.Join.ROUND);
			//goutput.setStroke(new BasicStroke((stroke_wid * 1.0f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
			//goutput.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			//goutput.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
			
			
			
			int[] strokes = new int[hr * wr];
			for(int i = 0; i < (hr * wr); i++) {
				strokes[i] = i;
			}
			
			for(int i = ((hr * wr) - 1); i >= 0; i--) {
				r = rand.nextInt(hr * wr);
				t = strokes[i];
				strokes[i] = strokes[r];
				strokes[r] = t;
			}
			
			
	
				for (int i = 0; i < (hr * wr); i++) {
					r = strokes[i];
					h = (r / wr) * scale;
					w = (r % wr) * scale;
					
					if( (h < stroke_len) || (w > (width - stroke_len)))
						continue;
					
					rgb = input.getPixel(w, h);
					
					rgb = perturbRGB(rgb);
					//goutput.setColor(new Color(rgb));
					p.setColor(rgb);
					
					goutput.drawLine((float)w, (float)h, 
							(float)(w+((stroke_len*(1+Math.random()))*1.0f)*Math.cos((Math.random()-.5)/3*Math.PI+Math.PI/4)), 
							(float)(h-((stroke_len*(1+Math.random()))*1.0f)*Math.sin((Math.random()-.5)/3*Math.PI+Math.PI/4)),
							p);
					
				}
				return(output);
			}

	
		private static int perturbRGB(int rgb) {
			//int newrgb = 0;
			int perturb = 25;
			int r = ((rgb >> 16) & 0xFF) + (int)(Math.random() * perturb) - perturb/2;
			int g = ((rgb >> 8) & 0xFF) + (int)(Math.random() * perturb) - perturb/2;
			int b = (rgb & 0xFF) + (int)(Math.random() * perturb) - perturb/2;
			
			r = (r > 0) ? ((r < 255) ? r : 255) : 0;
			g = (g > 0) ? ((g < 255) ? g : 255) : 0;
			b = (b > 0) ? ((b < 255) ? b : 255) : 0;

			//newrgb = r;
			//newrgb = (newrgb << 8) + g;
			//newrgb = (newrgb << 8) + b;
			//return newrgb;
			return Color.argb(255, r, g, b);
		}
		
		public Bitmap applyPencilSketch(Bitmap src)
		{
			Bitmap bmOut = Bitmap.createBitmap(src.getWidth(),src.getHeight(),src.getConfig());
			
			int A,R,G,B;
			int pixelColor;
			//double value;
			double thresh = 120.4;
			double row = 0.017;
			int height = src.getHeight();
			int width = src.getWidth();
			
			ConvolutionMatrix cm = new ConvolutionMatrix(3);
			/*double[][] data = new double[][]{
					{-0.4673,   -0.6793,   -0.7660,   -0.6793,   -0.4673},
					{-0.6793,   -0.7501,    0.6458,   -0.7501,   -0.6793},
					{-0.7660,    0.6458,   11.7843,    0.6458,   -0.7660},
					{-0.6793,   -0.7501,    0.6458,   -0.7501,   -0.6793},
					{-0.4673,   -0.6793,   -0.7660,   -0.6793,   -0.4673}
			};*/
			
			double[][] data = new double[][]{
					{0.0905,  0.0316, 0.0905},
					{0.0316, -0.4885, 0.0316},
					{0.0905,  0.0316, 0.0905}
			};
			
			cm.applyConfig(data);
			Bitmap temp = ConvolutionMatrix.computeConvolution3x3(src,cm);
			//Bitmap damn = temp;
			
			for(int y = 0; y < height; y++)
			{
				for(int x = 0; x < width; x++)
				{
					pixelColor = src.getPixel(x,y);
					A = Color.alpha(pixelColor);
					R = Color.red(pixelColor);
					G = Color.green(pixelColor);
					B = Color.blue(pixelColor);
					
					if(R > thresh)
					{
						R=G=B = 255;
					}
					else
					{
						R=G=B = 0;
								//(int) (255 + (255 * Math.tanh(row*(R - thresh))));
					}
					bmOut.setPixel(x,y,Color.argb(A,R,G,B));
				}
			}
			
			/*double[][] data2 = new double[][]{
					{0.0000,    0.0001,    0.0002,    0.0005,    0.0007, 0.0007,    0.0005,    0.0002,    0.0001,    0.0000},
					{0.0001,    0.0003,    0.0012,    0.0028,    0.0044, 0.0044,    0.0028,    0.0012,    0.0003,    0.0001},
					{0.0002,    0.0012,    0.0044,    0.0107,    0.0167, 0.0167,    0.0107,    0.0044,    0.0012,    0.0002},
					{0.0005,    0.0028,    0.0107,    0.0261,    0.0406, 0.0406,    0.0261,    0.0107,    0.0028,    0.0005},
					{0.0007,    0.0044,    0.0167,    0.0406,    0.0634, 0.0634,    0.0406,    0.0167,    0.0044,    0.0007},
					{0.0007,    0.0044,    0.0167,    0.0406,    0.0634, 0.0634,    0.0406,    0.0167,    0.0044,    0.0007},
					{0.0005,    0.0028,    0.0107,    0.0261,    0.0406, 0.0406,    0.0261,    0.0107,    0.0028,    0.0005},
					{0.0002,    0.0012,    0.0044,    0.0107,    0.0167, 0.0167,    0.0107,    0.0044,    0.0012,    0.0002},
					{0.0001,    0.0003,    0.0012,    0.0028,    0.0044, 0.0044,    0.0028,    0.0012,    0.0003,    0.0001},
					{0.0000,    0.0001,    0.0002,    0.0005,    0.0007, 0.0007,    0.0005,    0.0002,    0.0001,    0.0000}
			};
			
			ConvolutionMatrix matr = new ConvolutionMatrix(10);
			matr.applyConfig(data2);
			return ConvolutionMatrix.computeConvolution3x3(bmOut,matr);
			*/
			return bmOut;
		}
}